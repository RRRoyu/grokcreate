import { useEffect, useRef, type RefObject } from "react";
import { engine } from "@/lib/synth/engine";

export function Scope({ levelRef }: { levelRef: RefObject<HTMLSpanElement | null> }) {
  const polyRef = useRef<SVGPolylineElement>(null);
  const meterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const poly = polyRef.current;
    const meterEl = meterRef.current;
    if (!poly) return;

    let buf = new Uint8Array(0);
    let meter = 0;
    let raf = 0;
    let running = true;

    const draw = () => {
      if (!running) return;
      raf = requestAnimationFrame(draw);
      if (document.hidden) return;

      const svg = poly.ownerSVGElement;
      const w = svg?.clientWidth ?? 0;
      const h = svg?.clientHeight ?? 0;
      if (w < 2 || h < 2) return;

      const analyser = engine.getAnalyser();
      if (analyser) {
        if (buf.length !== analyser.fftSize) buf = new Uint8Array(analyser.fftSize);
        analyser.getByteTimeDomainData(buf);
        let maxDev = 0;
        for (let i = 0; i < buf.length; i++) {
          const dev = Math.abs(buf[i]! - 128);
          if (dev > maxDev) maxDev = dev;
        }
        const voiced = maxDev > 3;
        const scale = voiced ? Math.min(8, (h * 0.42) / maxDev) : h / 256;
        const step = Math.max(1, Math.floor(buf.length / 180));
        let points = "";
        for (let i = 0; i < buf.length; i += step) {
          const x = (i / (buf.length - 1)) * w;
          const y = h / 2 - (buf[i]! - 128) * scale;
          points += `${x.toFixed(1)},${y.toFixed(1)} `;
        }
        poly.setAttribute("points", points);
        const level = Math.min(1, (maxDev / 128) * engine.getVolume() * 1.6);
        meter = level > meter ? level : meter * 0.88;
      } else {
        meter *= 0.88;
        poly.setAttribute("points", `0,${(h / 2).toFixed(1)} ${w},${(h / 2).toFixed(1)}`);
      }

      if (meterEl) meterEl.style.transform = `scaleY(${Math.min(1, meter).toFixed(3)})`;
      const label = String(Math.round(Math.min(1, meter) * 100));
      if (levelRef.current && levelRef.current.textContent !== label) {
        levelRef.current.textContent = label;
      }
    };

    raf = requestAnimationFrame(draw);
    return () => {
      running = false;
      cancelAnimationFrame(raf);
    };
  }, [levelRef]);

  return (
    <div className="flex h-32 w-full gap-2 sm:h-40 xl:h-full xl:min-h-40">
      <svg className="h-full min-w-0 flex-1 overflow-visible" aria-hidden="true">
        <line x1="0" y1="50%" x2="100%" y2="50%" className="stroke-muted" strokeOpacity="0.35" strokeWidth="1" />
        <polyline
          ref={polyRef}
          fill="none"
          className="stroke-accent"
          strokeWidth="2"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
      </svg>
      <div className="relative my-1 h-auto w-1.5 shrink-0 self-stretch overflow-hidden rounded-full bg-muted/25" aria-hidden="true">
        <div
          ref={meterRef}
          className="absolute inset-x-0 bottom-0 h-full origin-bottom rounded-full bg-accent"
          style={{ transform: "scaleY(0)" }}
        />
      </div>
    </div>
  );
}
