import type { Waveform } from "@/lib/synth/params";

const PATHS: Record<Waveform, string> = {
  sine: "M1 11 C5 11 6 2 11 2 C16 2 16 20 21 20 C26 20 26 11 31 11",
  triangle: "M1 16 L8 4 L16 18 L24 4 L31 16",
  sawtooth: "M1 16 L9 4 V16 L17 4 V16 L25 4 V16 L31 6",
  square: "M1 16 V6 H9 V16 H17 V6 H25 V16 H31",
};

export function WaveIcon({ type }: { type: Waveform }) {
  return (
    <svg viewBox="0 0 32 22" className="h-4 w-7" aria-hidden="true">
      <path
        d={PATHS[type]}
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinejoin="round"
        strokeLinecap="round"
      />
    </svg>
  );
}
