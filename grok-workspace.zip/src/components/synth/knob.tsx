import { useRef } from "react";

type Curve = "linear" | "log";

type KnobProps = {
  label: string;
  hint: string;
  value: number;
  min: number;
  max: number;
  curve?: Curve;
  format: (value: number) => string;
  defaultValue: number;
  onChange: (value: number) => void;
};

function clamp01(n: number) {
  return Math.min(1, Math.max(0, n));
}

function toT(value: number, min: number, max: number, curve: Curve) {
  const v = Math.min(max, Math.max(min, value));
  if (curve === "log") {
    return (Math.log(v) - Math.log(min)) / (Math.log(max) - Math.log(min));
  }
  return (v - min) / (max - min);
}

function fromT(t: number, min: number, max: number, curve: Curve) {
  const c = clamp01(t);
  if (curve === "log") return Math.exp(Math.log(min) + c * (Math.log(max) - Math.log(min)));
  return min + c * (max - min);
}

function pt(deg: number, r: number) {
  const rad = (deg * Math.PI) / 180;
  return { x: 32 + r * Math.sin(rad), y: 32 - r * Math.cos(rad) };
}

function arcPath(from: number, to: number) {
  const sweep = ((to - from) % 360 + 360) % 360;
  const a = pt(from, 24);
  const b = pt(to, 24);
  const large = sweep > 180 ? 1 : 0;
  return `M ${a.x.toFixed(2)} ${a.y.toFixed(2)} A 24 24 0 ${large} 1 ${b.x.toFixed(2)} ${b.y.toFixed(2)}`;
}

export function Knob({
  label,
  hint,
  value,
  min,
  max,
  curve = "linear",
  format,
  defaultValue,
  onChange,
}: KnobProps) {
  const drag = useRef<{ y: number; t: number } | null>(null);
  const t = toT(value, min, max, curve);
  const angle = -135 + t * 270;
  const tip = pt(angle, 14);
  const text = format(value);

  function changeT(next: number) {
    onChange(fromT(next, min, max, curve));
  }

  return (
    <div className="flex w-16 flex-col items-center gap-1">
      <span className="font-mono text-xs leading-none text-muted">{label}</span>
      <div
        role="slider"
        aria-label={label}
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={value}
        aria-valuetext={text}
        aria-orientation="vertical"
        tabIndex={0}
        title={`${hint}。上下拖动，双击复位`}
        className="touch-none rounded-full transition-transform duration-150 ease-out active:scale-[0.96]"
        onPointerDown={(e) => {
          if (e.button !== 0) return;
          e.currentTarget.setPointerCapture(e.pointerId);
          drag.current = { y: e.clientY, t };
        }}
        onPointerMove={(e) => {
          if (!drag.current || !e.currentTarget.hasPointerCapture(e.pointerId)) return;
          const sens = e.shiftKey ? 420 : 160;
          const dy = drag.current.y - e.clientY;
          changeT(drag.current.t + dy / sens);
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
        onPointerCancel={() => {
          drag.current = null;
        }}
        onDoubleClick={() => onChange(defaultValue)}
        onKeyDown={(e) => {
          const step = e.shiftKey ? 0.01 : 0.04;
          if (e.key === "ArrowUp" || e.key === "ArrowRight") {
            e.preventDefault();
            changeT(t + step);
          } else if (e.key === "ArrowDown" || e.key === "ArrowLeft") {
            e.preventDefault();
            changeT(t - step);
          } else if (e.key === "Home") {
            e.preventDefault();
            onChange(min);
          } else if (e.key === "End") {
            e.preventDefault();
            onChange(max);
          }
        }}
      >
        <svg viewBox="0 0 64 64" className="size-16" aria-hidden="true">
          <circle cx="32" cy="32" r="22" className="fill-bg" />
          <path
            d={arcPath(-135, 135)}
            className="text-muted/40"
            stroke="currentColor"
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
          />
          {t > 0.012 ? (
            <path
              d={arcPath(-135, angle)}
              className="text-accent"
              stroke="currentColor"
              strokeWidth="3"
              fill="none"
              strokeLinecap="round"
            />
          ) : null}
          <line
            x1="32"
            y1="32"
            x2={tip.x}
            y2={tip.y}
            className="text-fg"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          />
          <circle cx="32" cy="32" r="2.5" className="fill-fg" />
        </svg>
      </div>
      <span className="font-mono text-xs leading-none text-fg tabular-nums">{text}</span>
    </div>
  );
}
