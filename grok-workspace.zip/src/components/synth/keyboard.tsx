import { useRef } from "react";
import { buildKeys, pitchClass, type KeyDef } from "@/lib/synth/params";
import { setSource } from "@/lib/synth/store";

type KeyboardProps = {
  octave: number;
  notes: number[];
};

export function Keyboard({ octave, notes }: KeyboardProps) {
  const { white, black } = buildKeys(octave);
  const active = useRef(new Set<number>());
  const down = new Set(notes);

  function hit(x: number, y: number): number | null {
    const el = document.elementFromPoint(x, y);
    const key = el?.closest("[data-midi]");
    if (!key) return null;
    const midi = Number(key.getAttribute("data-midi"));
    return Number.isFinite(midi) ? midi : null;
  }

  function movePointer(id: number, midi: number | null) {
    setSource(`p:${id}`, midi);
  }

  return (
    <div
      className="keybed"
      data-keybed
      onPointerDown={(e) => {
        if (e.pointerType === "mouse" && e.button !== 0) return;
        e.preventDefault();
        e.currentTarget.setPointerCapture(e.pointerId);
        active.current.add(e.pointerId);
        movePointer(e.pointerId, hit(e.clientX, e.clientY));
      }}
      onPointerMove={(e) => {
        if (!active.current.has(e.pointerId)) return;
        movePointer(e.pointerId, hit(e.clientX, e.clientY));
      }}
      onPointerUp={(e) => {
        active.current.delete(e.pointerId);
        movePointer(e.pointerId, null);
      }}
      onPointerCancel={(e) => {
        active.current.delete(e.pointerId);
        movePointer(e.pointerId, null);
      }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <div className="keybed-whites">
        {white.map((key) => (
          <Key key={key.midi} def={key} black={false} pressed={down.has(key.midi)} />
        ))}
      </div>
      {black.map((key) => (
        <Key key={key.midi} def={key} black pressed={down.has(key.midi)} />
      ))}
    </div>
  );
}

function Key({ def, black, pressed }: { def: KeyDef; black: boolean; pressed: boolean }) {
  return (
    <button
      type="button"
      tabIndex={-1}
      data-midi={def.midi}
      data-down={pressed ? "true" : "false"}
      aria-label={`${def.name}，键盘 ${def.label}`}
      aria-pressed={pressed}
      className={black ? "key-black" : "key-white"}
      style={black ? { left: `${def.leftPct}%` } : undefined}
    >
      <span className="font-mono text-xs leading-none">{def.label}</span>
      {black ? null : (
        <span className="hidden font-mono text-xs leading-none opacity-60 sm:block">
          {pitchClass(def.midi)}
        </span>
      )}
    </button>
  );
}
