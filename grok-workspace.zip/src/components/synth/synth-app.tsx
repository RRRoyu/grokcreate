import { useEffect, useRef, useSyncExternalStore } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Keyboard } from "@/components/synth/keyboard";
import { Knob } from "@/components/synth/knob";
import { Scope } from "@/components/synth/scope";
import { WaveIcon } from "@/components/synth/wave-icon";
import {
  CODE_TO_SEMI,
  DEFAULT_PARAMS,
  OCTAVE_MAX,
  OCTAVE_MIN,
  WAVEFORMS,
  WAVE_META,
  baseMidi,
  formatHz,
  formatPct,
  formatQ,
  formatTime,
  midiToFreq,
  midiToName,
  rangeLabel,
} from "@/lib/synth/params";
import {
  computerDown,
  computerUp,
  getSnap,
  hydrate,
  patchParams,
  releaseAll,
  shiftOctave,
  subscribe,
} from "@/lib/synth/store";

export function SynthApp() {
  const snap = useSyncExternalStore(subscribe, getSnap, getSnap);
  const levelRef = useRef<HTMLSpanElement>(null);
  const { params, notes, awake, lastMidi } = snap;
  const playing = notes.length > 0;

  useEffect(() => {
    hydrate();
  }, []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.code === "BracketLeft" || e.code === "BracketRight") {
        e.preventDefault();
        if (e.repeat) return;
        shiftOctave(e.code === "BracketRight" ? 1 : -1);
        return;
      }
      if (!(e.code in CODE_TO_SEMI)) return;
      e.preventDefault();
      if (e.repeat) return;
      computerDown(e.code);
    };
    const up = (e: KeyboardEvent) => {
      computerUp(e.code);
    };
    const blur = () => releaseAll();
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
      releaseAll();
    };
  }, []);

  const status = playing ? "演奏中" : awake ? "已通电 · 可以演奏" : "待机 · 按下琴键后才会发声";

  return (
    <div
      className="flex h-full flex-col overflow-hidden bg-bg text-fg"
      data-app
      data-awake={awake ? "true" : "false"}
      data-notes={notes.join(",")}
      data-octave={params.octave}
      data-waveform={params.waveform}
    >
      <div className="h-1 shrink-0 bg-accent" aria-hidden="true" />
      <div className="mx-auto flex min-h-0 w-full max-w-6xl flex-1 flex-col px-3 pt-3 sm:px-6 sm:pt-5">
        <header className="flex shrink-0 items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-baseline gap-2">
              <h1 className="text-2xl leading-none font-bold sm:text-3xl">琥珀线</h1>
              <span className="font-mono text-xs tracking-widest text-accent">AMBERLINE</span>
            </div>
            <p className="mt-1 text-xs leading-snug text-muted" aria-live="polite">
              {status}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <div className="flex items-center rounded-full border border-muted/25 bg-surface">
              <button
                type="button"
                className="flex size-11 items-center justify-center rounded-full text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40"
                aria-label="降低八度"
                disabled={params.octave <= OCTAVE_MIN}
                onClick={() => shiftOctave(-1)}
              >
                <ChevronLeft className="size-5" aria-hidden="true" />
              </button>
              <div className="min-w-8 text-center font-mono text-sm leading-none tabular-nums sm:min-w-16">
                <span className="sm:hidden">{midiToName(baseMidi(params.octave))}</span>
                <span className="hidden sm:inline">{rangeLabel(params.octave)}</span>
              </div>
              <button
                type="button"
                className="flex size-11 items-center justify-center rounded-full text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40"
                aria-label="升高八度"
                disabled={params.octave >= OCTAVE_MAX}
                onClick={() => shiftOctave(1)}
              >
                <ChevronRight className="size-5" aria-hidden="true" />
              </button>
            </div>
          </div>
        </header>

        <div className="mt-3 min-h-0 flex-1 overflow-auto overscroll-contain pb-2">
          <div className="grid gap-3 xl:h-full xl:grid-cols-[minmax(0,1.15fr)_minmax(18rem,0.85fr)]">
            <section className="order-2 rounded-3xl border border-muted/20 bg-surface p-3 sm:p-4 xl:order-1">
              <div className="flex items-baseline justify-between gap-3">
                <h2 className="text-sm font-medium">振荡器</h2>
                <span className="font-mono text-xs tracking-widest text-muted">OSC</span>
              </div>
              <div className="mt-3 grid grid-cols-4 gap-2" role="group" aria-label="波形">
                {WAVEFORMS.map((wave) => {
                  const active = params.waveform === wave;
                  return (
                    <button
                      key={wave}
                      type="button"
                      aria-pressed={active}
                      onClick={() => patchParams({ waveform: wave })}
                      className={
                        "flex h-12 flex-col items-center justify-center gap-0.5 rounded-xl border transition-colors duration-150 active:scale-[0.96] " +
                        (active
                          ? "border-accent bg-accent text-bg"
                          : "border-muted/25 bg-bg text-fg")
                      }
                    >
                      <WaveIcon type={wave} />
                      <span className="text-xs leading-none">{WAVE_META[wave].name}</span>
                    </button>
                  );
                })}
              </div>

              <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-[auto_1fr_auto] xl:items-end">
                <div>
                  <div className="mb-2 flex items-baseline justify-between gap-3">
                    <h3 className="text-sm font-medium">低通滤波</h3>
                    <span className="font-mono text-xs tracking-widest text-muted">FILTER</span>
                  </div>
                  <div className="flex gap-3">
                    <Knob
                      label="截止"
                      hint="滤波器截止频率"
                      value={params.cutoff}
                      min={80}
                      max={14000}
                      curve="log"
                      format={formatHz}
                      defaultValue={DEFAULT_PARAMS.cutoff}
                      onChange={(cutoff) => patchParams({ cutoff })}
                    />
                    <Knob
                      label="谐振"
                      hint="滤波器谐振"
                      value={params.resonance}
                      min={0.15}
                      max={18}
                      format={formatQ}
                      defaultValue={DEFAULT_PARAMS.resonance}
                      onChange={(resonance) => patchParams({ resonance })}
                    />
                  </div>
                </div>
                <div>
                  <div className="mb-2 flex items-baseline justify-between gap-3">
                    <h3 className="text-sm font-medium">包络</h3>
                    <span className="font-mono text-xs tracking-widest text-muted">ADSR</span>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Knob
                      label="起音"
                      hint="起音时间"
                      value={params.attack}
                      min={0.005}
                      max={2}
                      curve="log"
                      format={formatTime}
                      defaultValue={DEFAULT_PARAMS.attack}
                      onChange={(attack) => patchParams({ attack })}
                    />
                    <Knob
                      label="衰减"
                      hint="衰减时间"
                      value={params.decay}
                      min={0.02}
                      max={2.5}
                      curve="log"
                      format={formatTime}
                      defaultValue={DEFAULT_PARAMS.decay}
                      onChange={(decay) => patchParams({ decay })}
                    />
                    <Knob
                      label="延音"
                      hint="延音电平"
                      value={params.sustain}
                      min={0}
                      max={1}
                      format={formatPct}
                      defaultValue={DEFAULT_PARAMS.sustain}
                      onChange={(sustain) => patchParams({ sustain })}
                    />
                    <Knob
                      label="释音"
                      hint="释音时间"
                      value={params.release}
                      min={0.02}
                      max={4}
                      curve="log"
                      format={formatTime}
                      defaultValue={DEFAULT_PARAMS.release}
                      onChange={(release) => patchParams({ release })}
                    />
                  </div>
                </div>
                <div>
                  <div className="mb-2 flex items-baseline justify-between gap-3">
                    <h3 className="text-sm font-medium">输出</h3>
                    <span className="font-mono text-xs tracking-widest text-muted">LEVEL</span>
                  </div>
                  <Knob
                    label="音量"
                    hint="主音量"
                    value={params.volume}
                    min={0}
                    max={1}
                    format={formatPct}
                    defaultValue={DEFAULT_PARAMS.volume}
                    onChange={(volume) => patchParams({ volume })}
                  />
                </div>
              </div>
            </section>

            <section className="order-1 flex min-h-44 flex-col rounded-3xl border border-muted/20 bg-surface p-3 sm:p-4 xl:order-2 xl:h-full">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-baseline gap-3">
                    <h2 className="text-sm font-medium">示波器</h2>
                    <span className="font-mono text-xs tracking-widest text-muted">SCOPE</span>
                  </div>
                  <p className="mt-2 truncate text-2xl leading-none font-semibold">
                    {notes.length > 0 ? notes.map(midiToName).join(" ") : "—"}
                  </p>
                </div>
                <p className="shrink-0 text-right font-mono text-xs leading-relaxed text-muted">
                  {playing ? `${notes.length} 音` : "复音"}
                  <br />
                  {lastMidi != null
                    ? `${midiToName(lastMidi)} · ${formatHz(midiToFreq(lastMidi))}`
                    : "—"}
                </p>
              </div>
              <div className="relative mt-3 min-h-32 flex-1">
                <Scope levelRef={levelRef} />
                {awake ? null : (
                  <p className="pointer-events-none absolute inset-0 flex items-center justify-center font-mono text-xs text-muted">
                    等待信号
                  </p>
                )}
              </div>
              <p className="mt-2 font-mono text-xs text-muted">
                电平 <span ref={levelRef}>0</span>%
              </p>
            </section>
          </div>
        </div>

        <section className="shrink-0 pt-2 pb-3" aria-label="键盘">
          <div className="mb-2 flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-medium">键盘</h2>
            <p className="font-mono text-xs text-muted">{rangeLabel(params.octave)}</p>
          </div>
          <Keyboard octave={params.octave} notes={notes} />
          <p className="mt-2 font-mono text-xs leading-relaxed text-muted">
            低八度 Z S X D C V G B H N J M · 高八度 Q 2 W 3 E R 5 T 6 Y 7 U · 八度 [ ]
          </p>
        </section>
      </div>
    </div>
  );
}
