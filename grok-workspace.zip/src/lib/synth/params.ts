export const WAVEFORMS = ["sine", "triangle", "sawtooth", "square"] as const;
export type Waveform = (typeof WAVEFORMS)[number];

export type SynthParams = {
  waveform: Waveform;
  cutoff: number;
  resonance: number;
  attack: number;
  decay: number;
  sustain: number;
  release: number;
  volume: number;
  octave: number;
};

export const OCTAVE_MIN = 2;
export const OCTAVE_MAX = 6;
export const KEY_COUNT = 24;

export const DEFAULT_PARAMS: SynthParams = {
  waveform: "triangle",
  cutoff: 2200,
  resonance: 0.9,
  attack: 0.015,
  decay: 0.22,
  sustain: 0.7,
  release: 0.35,
  volume: 0.8,
  octave: 4,
};

export const WAVE_META: Record<Waveform, { name: string; en: string }> = {
  sine: { name: "正弦", en: "SINE" },
  triangle: { name: "三角", en: "TRI" },
  sawtooth: { name: "锯齿", en: "SAW" },
  square: { name: "方波", en: "SQR" },
};

/** Physical key positions, independent of the user's keyboard layout. */
export const CODE_TO_SEMI: Record<string, number> = {
  KeyZ: 0,
  KeyS: 1,
  KeyX: 2,
  KeyD: 3,
  KeyC: 4,
  KeyV: 5,
  KeyG: 6,
  KeyB: 7,
  KeyH: 8,
  KeyN: 9,
  KeyJ: 10,
  KeyM: 11,
  KeyQ: 12,
  Digit2: 13,
  KeyW: 14,
  Digit3: 15,
  KeyE: 16,
  KeyR: 17,
  Digit5: 18,
  KeyT: 19,
  Digit6: 20,
  KeyY: 21,
  Digit7: 22,
  KeyU: 23,
};

const PITCH = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"] as const;

const BLACK_PC = new Set([1, 3, 6, 8, 10]);

const LABEL_BY_SEMI: string[] = Array.from({ length: KEY_COUNT }, () => "");
for (const [code, semi] of Object.entries(CODE_TO_SEMI)) {
  LABEL_BY_SEMI[semi] = code.startsWith("Digit") ? code.slice(5) : code.slice(3);
}

export function semiLabel(semi: number): string {
  return LABEL_BY_SEMI[semi] ?? "";
}

export function isBlack(semi: number): boolean {
  return BLACK_PC.has(((semi % 12) + 12) % 12);
}

export function baseMidi(octave: number): number {
  return (octave + 1) * 12;
}

export function midiToName(midi: number): string {
  const pc = ((midi % 12) + 12) % 12;
  const oct = Math.floor(midi / 12) - 1;
  return `${PITCH[pc]}${oct}`;
}

export function pitchClass(midi: number): string {
  return PITCH[((midi % 12) + 12) % 12];
}

export function midiToFreq(midi: number): number {
  return 440 * 2 ** ((midi - 69) / 12);
}

export function rangeLabel(octave: number): string {
  const base = baseMidi(octave);
  return `${midiToName(base)}–${midiToName(base + KEY_COUNT - 1)}`;
}

/** Center of a black key as a percentage of the 14-white-key bed. */
export function blackLeftPct(semiFromBase: number): number {
  const preceding: Record<number, number> = { 1: 0, 3: 1, 6: 3, 8: 4, 10: 5 };
  const oct = Math.floor(semiFromBase / 12);
  const pc = semiFromBase % 12;
  const whiteIndex = oct * 7 + (preceding[pc] ?? 0);
  const center = ((whiteIndex + 1) / 14) * 100;
  return center - 2.2;
}

export type KeyDef = {
  midi: number;
  label: string;
  name: string;
  leftPct?: number;
};

export function buildKeys(octave: number): { white: KeyDef[]; black: KeyDef[] } {
  const base = baseMidi(octave);
  const white: KeyDef[] = [];
  const black: KeyDef[] = [];
  for (let semi = 0; semi < KEY_COUNT; semi++) {
    const midi = base + semi;
    const key: KeyDef = {
      midi,
      label: semiLabel(semi),
      name: midiToName(midi),
    };
    if (isBlack(semi)) {
      key.leftPct = blackLeftPct(semi);
      black.push(key);
    } else {
      white.push(key);
    }
  }
  return { white, black };
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

export function sanitize(raw: unknown): SynthParams {
  const d = DEFAULT_PARAMS;
  if (!raw || typeof raw !== "object") return { ...d };
  const o = raw as Record<string, unknown>;
  const num = (key: keyof SynthParams, min: number, max: number, fallback: number) => {
    const v = o[key];
    if (typeof v !== "number" || !Number.isFinite(v)) return fallback;
    return clamp(v, min, max);
  };
  const waveform =
    typeof o.waveform === "string" && (WAVEFORMS as readonly string[]).includes(o.waveform)
      ? (o.waveform as Waveform)
      : d.waveform;
  return {
    waveform,
    cutoff: num("cutoff", 80, 14000, d.cutoff),
    resonance: num("resonance", 0.15, 18, d.resonance),
    attack: num("attack", 0.005, 2, d.attack),
    decay: num("decay", 0.02, 2.5, d.decay),
    sustain: num("sustain", 0, 1, d.sustain),
    release: num("release", 0.02, 4, d.release),
    volume: num("volume", 0, 1, d.volume),
    octave: Math.round(num("octave", OCTAVE_MIN, OCTAVE_MAX, d.octave)),
  };
}

export function formatHz(hz: number): string {
  if (hz >= 1000) {
    const k = hz / 1000;
    return `${k >= 10 ? k.toFixed(0) : k.toFixed(1)} kHz`;
  }
  return `${Math.round(hz)} Hz`;
}

export function formatTime(seconds: number): string {
  const ms = Math.round(seconds * 1000);
  if (ms < 1000) return `${ms} ms`;
  return `${(ms / 1000).toFixed(2)} s`;
}

export function formatPct(value: number): string {
  return `${Math.round(value * 100)}%`;
}

export function formatQ(q: number): string {
  return q.toFixed(1);
}
