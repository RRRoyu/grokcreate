import type { SynthParams, Waveform } from "@/lib/synth/params";
import { DEFAULT_PARAMS, midiToFreq } from "@/lib/synth/params";

const PEAK: Record<Waveform, number> = {
  sine: 0.28,
  triangle: 0.24,
  sawtooth: 0.14,
  square: 0.11,
};

type Voice = {
  osc: OscillatorNode;
  gain: GainNode;
};

/**
 * Polyphonic subtractive synth. The AudioContext is created only from a user
 * gesture (ensure), never at import or page load.
 */
class SynthEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private analyser: AnalyserNode | null = null;
  private voices = new Map<number, Voice>();
  private settings: SynthParams = { ...DEFAULT_PARAMS };

  getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  getVolume(): number {
    return this.settings.volume;
  }

  setSettings(next: SynthParams) {
    this.settings = next;
    this.applyAudio();
  }

  ensure(): boolean {
    if (typeof window === "undefined") return false;
    const AC = window.AudioContext;
    if (!AC) return false;
    try {
      if (!this.ctx) this.build(new AC());
      if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
      return this.ctx != null;
    } catch {
      return false;
    }
  }

  noteOn(midi: number) {
    if (!this.ensure() || !this.ctx || !this.filter) return;
    const existing = this.voices.get(midi);
    if (existing) {
      this.shape(existing.gain, this.ctx.currentTime);
      return;
    }
    const ctx = this.ctx;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = this.settings.waveform;
    osc.frequency.value = midiToFreq(midi);
    gain.gain.value = 0.0001;
    osc.connect(gain);
    gain.connect(this.filter);
    osc.start(now);
    this.shape(gain, now);
    this.voices.set(midi, { osc, gain });
  }

  noteOff(midi: number) {
    const voice = this.voices.get(midi);
    if (!voice || !this.ctx) return;
    this.voices.delete(midi);
    const now = this.ctx.currentTime;
    const rel = Math.max(0.02, this.settings.release);
    const g = voice.gain.gain;
    try {
      if (typeof g.cancelAndHoldAtTime === "function") g.cancelAndHoldAtTime(now);
      else g.cancelScheduledValues(now);
      g.exponentialRampToValueAtTime(0.0001, now + rel);
    } catch {
      g.cancelScheduledValues(now);
      g.setValueAtTime(0.0001, now);
    }
    const stopAt = now + rel + 0.05;
    try {
      voice.osc.stop(stopAt);
    } catch {
      /* already stopped */
    }
    voice.osc.onended = () => {
      try {
        voice.osc.disconnect();
        voice.gain.disconnect();
      } catch {
        /* already disconnected */
      }
    };
  }

  private build(ctx: AudioContext) {
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = this.settings.cutoff;
    filter.Q.value = this.settings.resonance;

    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14;
    comp.knee.value = 18;
    comp.ratio.value = 4;
    comp.attack.value = 0.004;
    comp.release.value = 0.18;

    const master = ctx.createGain();
    master.gain.value = this.settings.volume;

    const analyser = ctx.createAnalyser();
    analyser.fftSize = 1024;
    analyser.smoothingTimeConstant = 0.15;

    filter.connect(comp);
    comp.connect(master);
    master.connect(analyser);
    analyser.connect(ctx.destination);

    this.ctx = ctx;
    this.filter = filter;
    this.master = master;
    this.analyser = analyser;
  }

  private applyAudio() {
    if (!this.ctx || !this.filter || !this.master) return;
    const now = this.ctx.currentTime;
    this.filter.frequency.setTargetAtTime(this.settings.cutoff, now, 0.02);
    this.filter.Q.setTargetAtTime(this.settings.resonance, now, 0.02);
    this.master.gain.setTargetAtTime(this.settings.volume, now, 0.015);
    for (const voice of this.voices.values()) {
      voice.osc.type = this.settings.waveform;
    }
  }

  private shape(gain: GainNode, now: number) {
    const { attack, decay, sustain, waveform } = this.settings;
    const peak = Math.max(0.0001, PEAK[waveform]);
    const sus = Math.max(0.0001, peak * sustain);
    const a = Math.max(0.005, attack);
    const d = Math.max(0.005, decay);
    const g = gain.gain;
    g.cancelScheduledValues(now);
    g.setValueAtTime(0.0001, now);
    g.exponentialRampToValueAtTime(peak, now + a);
    g.exponentialRampToValueAtTime(sus, now + a + d);
  }
}

export const engine = new SynthEngine();
