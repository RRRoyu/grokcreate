import { engine } from "@/lib/synth/engine";
import {
  CODE_TO_SEMI,
  DEFAULT_PARAMS,
  KEY_COUNT,
  baseMidi,
  sanitize,
  type SynthParams,
} from "@/lib/synth/params";

const STORAGE_KEY = "amberline-params-v1";

export type SynthSnap = {
  params: SynthParams;
  notes: number[];
  awake: boolean;
  lastMidi: number | null;
};

let snap: SynthSnap = {
  params: { ...DEFAULT_PARAMS },
  notes: [],
  awake: false,
  lastMidi: null,
};

const listeners = new Set<() => void>();
const sources = new Map<string, number>();
const counts = new Map<number, number>();
let ready = false;

export function subscribe(fn: () => void): () => void {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function getSnap(): SynthSnap {
  return snap;
}

function emit() {
  for (const fn of listeners) fn();
}

function publish() {
  snap = {
    ...snap,
    notes: [...counts.keys()].sort((a, b) => a - b),
  };
  emit();
}

function arm() {
  const ok = engine.ensure();
  if (ok && !snap.awake) snap = { ...snap, awake: true };
}

function changeCount(midi: number, delta: number) {
  const current = counts.get(midi) ?? 0;
  const next = current + delta;
  if (next <= 0) {
    if (current > 0) {
      counts.delete(midi);
      engine.noteOff(midi);
    }
    return;
  }
  counts.set(midi, next);
  if (current === 0 && delta > 0) {
    arm();
    engine.noteOn(midi);
    snap = { ...snap, lastMidi: midi };
  }
}

/** Assign a pointer or computer-key source to a midi note, or null to release. */
export function setSource(id: string, midi: number | null) {
  const prev = sources.get(id) ?? null;
  if (prev === midi) return;
  if (prev != null) changeCount(prev, -1);
  if (midi == null) sources.delete(id);
  else {
    sources.set(id, midi);
    changeCount(midi, 1);
  }
  publish();
}

export function computerDown(code: string) {
  const semi = CODE_TO_SEMI[code];
  if (semi == null) return;
  const id = `k:${code}`;
  if (sources.has(id)) return;
  setSource(id, baseMidi(snap.params.octave) + semi);
}

export function computerUp(code: string) {
  const id = `k:${code}`;
  if (!sources.has(id)) return;
  setSource(id, null);
}

export function releaseAll() {
  for (const id of [...sources.keys()]) setSource(id, null);
}

function retargetHeld(octave: number, prev: number) {
  const prevBase = baseMidi(prev);
  const nextBase = baseMidi(octave);
  const updates: Array<[string, number | null]> = [];
  for (const [id, midi] of sources) {
    if (id.startsWith("k:")) {
      const semi = CODE_TO_SEMI[id.slice(2)];
      updates.push([id, semi == null ? null : nextBase + semi]);
      continue;
    }
    const semi = midi - prevBase;
    updates.push([id, semi >= 0 && semi < KEY_COUNT ? nextBase + semi : null]);
  }
  for (const [id, midi] of updates) setSource(id, midi);
}

export function patchParams(patch: Partial<SynthParams>) {
  const next = sanitize({ ...snap.params, ...patch });
  if (JSON.stringify(next) === JSON.stringify(snap.params)) return;
  const prevOctave = snap.params.octave;
  engine.setSettings(next);
  snap = { ...snap, params: next };
  if (ready && typeof localStorage !== "undefined") {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }
  if (next.octave !== prevOctave) retargetHeld(next.octave, prevOctave);
  emit();
}

export function shiftOctave(dir: number) {
  patchParams({ octave: snap.params.octave + dir });
}

export function hydrate() {
  if (ready || typeof localStorage === "undefined") return;
  ready = true;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    patchParams(sanitize(JSON.parse(raw) as unknown));
  } catch {
    /* ignore broken storage */
  }
}
