import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as ChevronRight, r as ChevronLeft } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Cldfjqda.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var WAVEFORMS = [
	"sine",
	"triangle",
	"sawtooth",
	"square"
];
var DEFAULT_PARAMS = {
	waveform: "triangle",
	cutoff: 2200,
	resonance: .9,
	attack: .015,
	decay: .22,
	sustain: .7,
	release: .35,
	volume: .8,
	octave: 4
};
var WAVE_META = {
	sine: {
		name: "正弦",
		en: "SINE"
	},
	triangle: {
		name: "三角",
		en: "TRI"
	},
	sawtooth: {
		name: "锯齿",
		en: "SAW"
	},
	square: {
		name: "方波",
		en: "SQR"
	}
};
/** Physical key positions, independent of the user's keyboard layout. */
var CODE_TO_SEMI = {
	KeyZ: 0,
	KeyS: 1,
	KeyX: 2,
	KeyD: 3,
	KeyC: 4,
	KeyV: 5,
	KeyG: 6,
	KeyB: 7,
	KeyH: 8,
	KeyN: 9,
	KeyJ: 10,
	KeyM: 11,
	KeyQ: 12,
	Digit2: 13,
	KeyW: 14,
	Digit3: 15,
	KeyE: 16,
	KeyR: 17,
	Digit5: 18,
	KeyT: 19,
	Digit6: 20,
	KeyY: 21,
	Digit7: 22,
	KeyU: 23
};
var PITCH = [
	"C",
	"C#",
	"D",
	"D#",
	"E",
	"F",
	"F#",
	"G",
	"G#",
	"A",
	"A#",
	"B"
];
var BLACK_PC = /* @__PURE__ */ new Set([
	1,
	3,
	6,
	8,
	10
]);
var LABEL_BY_SEMI = Array.from({ length: 24 }, () => "");
for (const [code, semi] of Object.entries(CODE_TO_SEMI)) LABEL_BY_SEMI[semi] = code.startsWith("Digit") ? code.slice(5) : code.slice(3);
function semiLabel(semi) {
	return LABEL_BY_SEMI[semi] ?? "";
}
function isBlack(semi) {
	return BLACK_PC.has((semi % 12 + 12) % 12);
}
function baseMidi(octave) {
	return (octave + 1) * 12;
}
function midiToName(midi) {
	const pc = (midi % 12 + 12) % 12;
	const oct = Math.floor(midi / 12) - 1;
	return `${PITCH[pc]}${oct}`;
}
function pitchClass(midi) {
	return PITCH[(midi % 12 + 12) % 12];
}
function midiToFreq(midi) {
	return 440 * 2 ** ((midi - 69) / 12);
}
function rangeLabel(octave) {
	const base = baseMidi(octave);
	return `${midiToName(base)}–${midiToName(base + 24 - 1)}`;
}
/** Center of a black key as a percentage of the 14-white-key bed. */
function blackLeftPct(semiFromBase) {
	const preceding = {
		1: 0,
		3: 1,
		6: 3,
		8: 4,
		10: 5
	};
	const oct = Math.floor(semiFromBase / 12);
	const pc = semiFromBase % 12;
	return (oct * 7 + (preceding[pc] ?? 0) + 1) / 14 * 100 - 2.2;
}
function buildKeys(octave) {
	const base = baseMidi(octave);
	const white = [];
	const black = [];
	for (let semi = 0; semi < 24; semi++) {
		const midi = base + semi;
		const key = {
			midi,
			label: semiLabel(semi),
			name: midiToName(midi)
		};
		if (isBlack(semi)) {
			key.leftPct = blackLeftPct(semi);
			black.push(key);
		} else white.push(key);
	}
	return {
		white,
		black
	};
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function sanitize(raw) {
	const d = DEFAULT_PARAMS;
	if (!raw || typeof raw !== "object") return { ...d };
	const o = raw;
	const num = (key, min, max, fallback) => {
		const v = o[key];
		if (typeof v !== "number" || !Number.isFinite(v)) return fallback;
		return clamp(v, min, max);
	};
	return {
		waveform: typeof o.waveform === "string" && WAVEFORMS.includes(o.waveform) ? o.waveform : d.waveform,
		cutoff: num("cutoff", 80, 14e3, d.cutoff),
		resonance: num("resonance", .15, 18, d.resonance),
		attack: num("attack", .005, 2, d.attack),
		decay: num("decay", .02, 2.5, d.decay),
		sustain: num("sustain", 0, 1, d.sustain),
		release: num("release", .02, 4, d.release),
		volume: num("volume", 0, 1, d.volume),
		octave: Math.round(num("octave", 2, 6, d.octave))
	};
}
function formatHz(hz) {
	if (hz >= 1e3) {
		const k = hz / 1e3;
		return `${k >= 10 ? k.toFixed(0) : k.toFixed(1)} kHz`;
	}
	return `${Math.round(hz)} Hz`;
}
function formatTime(seconds) {
	const ms = Math.round(seconds * 1e3);
	if (ms < 1e3) return `${ms} ms`;
	return `${(ms / 1e3).toFixed(2)} s`;
}
function formatPct(value) {
	return `${Math.round(value * 100)}%`;
}
function formatQ(q) {
	return q.toFixed(1);
}
var PEAK = {
	sine: .28,
	triangle: .24,
	sawtooth: .14,
	square: .11
};
/**
* Polyphonic subtractive synth. The AudioContext is created only from a user
* gesture (ensure), never at import or page load.
*/
var SynthEngine = class {
	ctx = null;
	master = null;
	filter = null;
	analyser = null;
	voices = /* @__PURE__ */ new Map();
	settings = { ...DEFAULT_PARAMS };
	getAnalyser() {
		return this.analyser;
	}
	getVolume() {
		return this.settings.volume;
	}
	setSettings(next) {
		this.settings = next;
		this.applyAudio();
	}
	ensure() {
		if (typeof window === "undefined") return false;
		const AC = window.AudioContext;
		if (!AC) return false;
		try {
			if (!this.ctx) this.build(new AC());
			if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
			return this.ctx != null;
		} catch {
			return false;
		}
	}
	noteOn(midi) {
		if (!this.ensure() || !this.ctx || !this.filter) return;
		const existing = this.voices.get(midi);
		if (existing) {
			this.shape(existing.gain, this.ctx.currentTime);
			return;
		}
		const ctx = this.ctx;
		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = this.settings.waveform;
		osc.frequency.value = midiToFreq(midi);
		gain.gain.value = 1e-4;
		osc.connect(gain);
		gain.connect(this.filter);
		osc.start(now);
		this.shape(gain, now);
		this.voices.set(midi, {
			osc,
			gain
		});
	}
	noteOff(midi) {
		const voice = this.voices.get(midi);
		if (!voice || !this.ctx) return;
		this.voices.delete(midi);
		const now = this.ctx.currentTime;
		const rel = Math.max(.02, this.settings.release);
		const g = voice.gain.gain;
		try {
			if (typeof g.cancelAndHoldAtTime === "function") g.cancelAndHoldAtTime(now);
			else g.cancelScheduledValues(now);
			g.exponentialRampToValueAtTime(1e-4, now + rel);
		} catch {
			g.cancelScheduledValues(now);
			g.setValueAtTime(1e-4, now);
		}
		const stopAt = now + rel + .05;
		try {
			voice.osc.stop(stopAt);
		} catch {}
		voice.osc.onended = () => {
			try {
				voice.osc.disconnect();
				voice.gain.disconnect();
			} catch {}
		};
	}
	build(ctx) {
		const filter = ctx.createBiquadFilter();
		filter.type = "lowpass";
		filter.frequency.value = this.settings.cutoff;
		filter.Q.value = this.settings.resonance;
		const comp = ctx.createDynamicsCompressor();
		comp.threshold.value = -14;
		comp.knee.value = 18;
		comp.ratio.value = 4;
		comp.attack.value = .004;
		comp.release.value = .18;
		const master = ctx.createGain();
		master.gain.value = this.settings.volume;
		const analyser = ctx.createAnalyser();
		analyser.fftSize = 1024;
		analyser.smoothingTimeConstant = .15;
		filter.connect(comp);
		comp.connect(master);
		master.connect(analyser);
		analyser.connect(ctx.destination);
		this.ctx = ctx;
		this.filter = filter;
		this.master = master;
		this.analyser = analyser;
	}
	applyAudio() {
		if (!this.ctx || !this.filter || !this.master) return;
		const now = this.ctx.currentTime;
		this.filter.frequency.setTargetAtTime(this.settings.cutoff, now, .02);
		this.filter.Q.setTargetAtTime(this.settings.resonance, now, .02);
		this.master.gain.setTargetAtTime(this.settings.volume, now, .015);
		for (const voice of this.voices.values()) voice.osc.type = this.settings.waveform;
	}
	shape(gain, now) {
		const { attack, decay, sustain, waveform } = this.settings;
		const peak = Math.max(1e-4, PEAK[waveform]);
		const sus = Math.max(1e-4, peak * sustain);
		const a = Math.max(.005, attack);
		const d = Math.max(.005, decay);
		const g = gain.gain;
		g.cancelScheduledValues(now);
		g.setValueAtTime(1e-4, now);
		g.exponentialRampToValueAtTime(peak, now + a);
		g.exponentialRampToValueAtTime(sus, now + a + d);
	}
};
var engine = new SynthEngine();
var STORAGE_KEY = "amberline-params-v1";
var snap = {
	params: { ...DEFAULT_PARAMS },
	notes: [],
	awake: false,
	lastMidi: null
};
var listeners = /* @__PURE__ */ new Set();
var sources = /* @__PURE__ */ new Map();
var counts = /* @__PURE__ */ new Map();
var ready = false;
function subscribe(fn) {
	listeners.add(fn);
	return () => listeners.delete(fn);
}
function getSnap() {
	return snap;
}
function emit() {
	for (const fn of listeners) fn();
}
function publish() {
	snap = {
		...snap,
		notes: [...counts.keys()].sort((a, b) => a - b)
	};
	emit();
}
function arm() {
	if (engine.ensure() && !snap.awake) snap = {
		...snap,
		awake: true
	};
}
function changeCount(midi, delta) {
	const current = counts.get(midi) ?? 0;
	const next = current + delta;
	if (next <= 0) {
		if (current > 0) {
			counts.delete(midi);
			engine.noteOff(midi);
		}
		return;
	}
	counts.set(midi, next);
	if (current === 0 && delta > 0) {
		arm();
		engine.noteOn(midi);
		snap = {
			...snap,
			lastMidi: midi
		};
	}
}
/** Assign a pointer or computer-key source to a midi note, or null to release. */
function setSource(id, midi) {
	const prev = sources.get(id) ?? null;
	if (prev === midi) return;
	if (prev != null) changeCount(prev, -1);
	if (midi == null) sources.delete(id);
	else {
		sources.set(id, midi);
		changeCount(midi, 1);
	}
	publish();
}
function computerDown(code) {
	const semi = CODE_TO_SEMI[code];
	if (semi == null) return;
	const id = `k:${code}`;
	if (sources.has(id)) return;
	setSource(id, baseMidi(snap.params.octave) + semi);
}
function computerUp(code) {
	const id = `k:${code}`;
	if (!sources.has(id)) return;
	setSource(id, null);
}
function releaseAll() {
	for (const id of [...sources.keys()]) setSource(id, null);
}
function retargetHeld(octave, prev) {
	const prevBase = baseMidi(prev);
	const nextBase = baseMidi(octave);
	const updates = [];
	for (const [id, midi] of sources) {
		if (id.startsWith("k:")) {
			const semi = CODE_TO_SEMI[id.slice(2)];
			updates.push([id, semi == null ? null : nextBase + semi]);
			continue;
		}
		const semi = midi - prevBase;
		updates.push([id, semi >= 0 && semi < 24 ? nextBase + semi : null]);
	}
	for (const [id, midi] of updates) setSource(id, midi);
}
function patchParams(patch) {
	const next = sanitize({
		...snap.params,
		...patch
	});
	if (JSON.stringify(next) === JSON.stringify(snap.params)) return;
	const prevOctave = snap.params.octave;
	engine.setSettings(next);
	snap = {
		...snap,
		params: next
	};
	if (ready && typeof localStorage !== "undefined") localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
	if (next.octave !== prevOctave) retargetHeld(next.octave, prevOctave);
	emit();
}
function shiftOctave(dir) {
	patchParams({ octave: snap.params.octave + dir });
}
function hydrate() {
	if (ready || typeof localStorage === "undefined") return;
	ready = true;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return;
		patchParams(sanitize(JSON.parse(raw)));
	} catch {}
}
function Keyboard({ octave, notes }) {
	const { white, black } = buildKeys(octave);
	const active = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const down = new Set(notes);
	function hit(x, y) {
		const key = document.elementFromPoint(x, y)?.closest("[data-midi]");
		if (!key) return null;
		const midi = Number(key.getAttribute("data-midi"));
		return Number.isFinite(midi) ? midi : null;
	}
	function movePointer(id, midi) {
		setSource(`p:${id}`, midi);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "keybed",
		"data-keybed": true,
		onPointerDown: (e) => {
			if (e.pointerType === "mouse" && e.button !== 0) return;
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			active.current.add(e.pointerId);
			movePointer(e.pointerId, hit(e.clientX, e.clientY));
		},
		onPointerMove: (e) => {
			if (!active.current.has(e.pointerId)) return;
			movePointer(e.pointerId, hit(e.clientX, e.clientY));
		},
		onPointerUp: (e) => {
			active.current.delete(e.pointerId);
			movePointer(e.pointerId, null);
		},
		onPointerCancel: (e) => {
			active.current.delete(e.pointerId);
			movePointer(e.pointerId, null);
		},
		onContextMenu: (e) => e.preventDefault(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "keybed-whites",
			children: white.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
				def: key,
				black: false,
				pressed: down.has(key.midi)
			}, key.midi))
		}), black.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Key, {
			def: key,
			black: true,
			pressed: down.has(key.midi)
		}, key.midi))]
	});
}
function Key({ def, black, pressed }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		tabIndex: -1,
		"data-midi": def.midi,
		"data-down": pressed ? "true" : "false",
		"aria-label": `${def.name}，键盘 ${def.label}`,
		"aria-pressed": pressed,
		className: black ? "key-black" : "key-white",
		style: black ? { left: `${def.leftPct}%` } : void 0,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-mono text-xs leading-none",
			children: def.label
		}), black ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden font-mono text-xs leading-none opacity-60 sm:block",
			children: pitchClass(def.midi)
		})]
	});
}
function clamp01(n) {
	return Math.min(1, Math.max(0, n));
}
function toT(value, min, max, curve) {
	const v = Math.min(max, Math.max(min, value));
	if (curve === "log") return (Math.log(v) - Math.log(min)) / (Math.log(max) - Math.log(min));
	return (v - min) / (max - min);
}
function fromT(t, min, max, curve) {
	const c = clamp01(t);
	if (curve === "log") return Math.exp(Math.log(min) + c * (Math.log(max) - Math.log(min)));
	return min + c * (max - min);
}
function pt(deg, r) {
	const rad = deg * Math.PI / 180;
	return {
		x: 32 + r * Math.sin(rad),
		y: 32 - r * Math.cos(rad)
	};
}
function arcPath(from, to) {
	const sweep = ((to - from) % 360 + 360) % 360;
	const a = pt(from, 24);
	const b = pt(to, 24);
	const large = sweep > 180 ? 1 : 0;
	return `M ${a.x.toFixed(2)} ${a.y.toFixed(2)} A 24 24 0 ${large} 1 ${b.x.toFixed(2)} ${b.y.toFixed(2)}`;
}
function Knob({ label, hint, value, min, max, curve = "linear", format, defaultValue, onChange }) {
	const drag = (0, import_react.useRef)(null);
	const t = toT(value, min, max, curve);
	const angle = -135 + t * 270;
	const tip = pt(angle, 14);
	const text = format(value);
	function changeT(next) {
		onChange(fromT(next, min, max, curve));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex w-16 flex-col items-center gap-1",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs leading-none text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "slider",
				"aria-label": label,
				"aria-valuemin": min,
				"aria-valuemax": max,
				"aria-valuenow": value,
				"aria-valuetext": text,
				"aria-orientation": "vertical",
				tabIndex: 0,
				title: `${hint}。上下拖动，双击复位`,
				className: "touch-none rounded-full transition-transform duration-150 ease-out active:scale-[0.96]",
				onPointerDown: (e) => {
					if (e.button !== 0) return;
					e.currentTarget.setPointerCapture(e.pointerId);
					drag.current = {
						y: e.clientY,
						t
					};
				},
				onPointerMove: (e) => {
					if (!drag.current || !e.currentTarget.hasPointerCapture(e.pointerId)) return;
					const sens = e.shiftKey ? 420 : 160;
					const dy = drag.current.y - e.clientY;
					changeT(drag.current.t + dy / sens);
				},
				onPointerUp: () => {
					drag.current = null;
				},
				onPointerCancel: () => {
					drag.current = null;
				},
				onDoubleClick: () => onChange(defaultValue),
				onKeyDown: (e) => {
					const step = e.shiftKey ? .01 : .04;
					if (e.key === "ArrowUp" || e.key === "ArrowRight") {
						e.preventDefault();
						changeT(t + step);
					} else if (e.key === "ArrowDown" || e.key === "ArrowLeft") {
						e.preventDefault();
						changeT(t - step);
					} else if (e.key === "Home") {
						e.preventDefault();
						onChange(min);
					} else if (e.key === "End") {
						e.preventDefault();
						onChange(max);
					}
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					viewBox: "0 0 64 64",
					className: "size-16",
					"aria-hidden": "true",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "32",
							cy: "32",
							r: "22",
							className: "fill-bg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: arcPath(-135, 135),
							className: "text-muted/40",
							stroke: "currentColor",
							strokeWidth: "3",
							fill: "none",
							strokeLinecap: "round"
						}),
						t > .012 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: arcPath(-135, angle),
							className: "text-accent",
							stroke: "currentColor",
							strokeWidth: "3",
							fill: "none",
							strokeLinecap: "round"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "32",
							y1: "32",
							x2: tip.x,
							y2: tip.y,
							className: "text-fg",
							stroke: "currentColor",
							strokeWidth: "2",
							strokeLinecap: "round"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "32",
							cy: "32",
							r: "2.5",
							className: "fill-fg"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-xs leading-none text-fg tabular-nums",
				children: text
			})
		]
	});
}
function Scope({ levelRef }) {
	const polyRef = (0, import_react.useRef)(null);
	const meterRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const poly = polyRef.current;
		const meterEl = meterRef.current;
		if (!poly) return;
		let buf = /* @__PURE__ */ new Uint8Array(0);
		let meter = 0;
		let raf = 0;
		let running = true;
		const draw = () => {
			if (!running) return;
			raf = requestAnimationFrame(draw);
			if (document.hidden) return;
			const svg = poly.ownerSVGElement;
			const w = svg?.clientWidth ?? 0;
			const h = svg?.clientHeight ?? 0;
			if (w < 2 || h < 2) return;
			const analyser = engine.getAnalyser();
			if (analyser) {
				if (buf.length !== analyser.fftSize) buf = new Uint8Array(analyser.fftSize);
				analyser.getByteTimeDomainData(buf);
				let maxDev = 0;
				for (let i = 0; i < buf.length; i++) {
					const dev = Math.abs(buf[i] - 128);
					if (dev > maxDev) maxDev = dev;
				}
				const scale = maxDev > 3 ? Math.min(8, h * .42 / maxDev) : h / 256;
				const step = Math.max(1, Math.floor(buf.length / 180));
				let points = "";
				for (let i = 0; i < buf.length; i += step) {
					const x = i / (buf.length - 1) * w;
					const y = h / 2 - (buf[i] - 128) * scale;
					points += `${x.toFixed(1)},${y.toFixed(1)} `;
				}
				poly.setAttribute("points", points);
				const level = Math.min(1, maxDev / 128 * engine.getVolume() * 1.6);
				meter = level > meter ? level : meter * .88;
			} else {
				meter *= .88;
				poly.setAttribute("points", `0,${(h / 2).toFixed(1)} ${w},${(h / 2).toFixed(1)}`);
			}
			if (meterEl) meterEl.style.transform = `scaleY(${Math.min(1, meter).toFixed(3)})`;
			const label = String(Math.round(Math.min(1, meter) * 100));
			if (levelRef.current && levelRef.current.textContent !== label) levelRef.current.textContent = label;
		};
		raf = requestAnimationFrame(draw);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
		};
	}, [levelRef]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-32 w-full gap-2 sm:h-40 xl:h-full xl:min-h-40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "h-full min-w-0 flex-1 overflow-visible",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "0",
				y1: "50%",
				x2: "100%",
				y2: "50%",
				className: "stroke-muted",
				strokeOpacity: "0.35",
				strokeWidth: "1"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
				ref: polyRef,
				fill: "none",
				className: "stroke-accent",
				strokeWidth: "2",
				strokeLinejoin: "round",
				strokeLinecap: "round"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative my-1 h-auto w-1.5 shrink-0 self-stretch overflow-hidden rounded-full bg-muted/25",
			"aria-hidden": "true",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: meterRef,
				className: "absolute inset-x-0 bottom-0 h-full origin-bottom rounded-full bg-accent",
				style: { transform: "scaleY(0)" }
			})
		})]
	});
}
var PATHS = {
	sine: "M1 11 C5 11 6 2 11 2 C16 2 16 20 21 20 C26 20 26 11 31 11",
	triangle: "M1 16 L8 4 L16 18 L24 4 L31 16",
	sawtooth: "M1 16 L9 4 V16 L17 4 V16 L25 4 V16 L31 6",
	square: "M1 16 V6 H9 V16 H17 V6 H25 V16 H31"
};
function WaveIcon({ type }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 32 22",
		className: "h-4 w-7",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: PATHS[type],
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.7",
			strokeLinejoin: "round",
			strokeLinecap: "round"
		})
	});
}
function SynthApp() {
	const snap = (0, import_react.useSyncExternalStore)(subscribe, getSnap, getSnap);
	const levelRef = (0, import_react.useRef)(null);
	const { params, notes, awake, lastMidi } = snap;
	const playing = notes.length > 0;
	(0, import_react.useEffect)(() => {
		hydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		const down = (e) => {
			if (e.metaKey || e.ctrlKey || e.altKey) return;
			if (e.code === "BracketLeft" || e.code === "BracketRight") {
				e.preventDefault();
				if (e.repeat) return;
				shiftOctave(e.code === "BracketRight" ? 1 : -1);
				return;
			}
			if (!(e.code in CODE_TO_SEMI)) return;
			e.preventDefault();
			if (e.repeat) return;
			computerDown(e.code);
		};
		const up = (e) => {
			computerUp(e.code);
		};
		const blur = () => releaseAll();
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", blur);
		return () => {
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", blur);
			releaseAll();
		};
	}, []);
	const status = playing ? "演奏中" : awake ? "已通电 · 可以演奏" : "待机 · 按下琴键后才会发声";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col overflow-hidden bg-bg text-fg",
		"data-app": true,
		"data-awake": awake ? "true" : "false",
		"data-notes": notes.join(","),
		"data-octave": params.octave,
		"data-waveform": params.waveform,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1 shrink-0 bg-accent",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-0 w-full max-w-6xl flex-1 flex-col px-3 pt-3 sm:px-6 sm:pt-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex shrink-0 items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl leading-none font-bold sm:text-3xl",
								children: "琥珀线"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs tracking-widest text-accent",
								children: "AMBERLINE"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs leading-snug text-muted",
							"aria-live": "polite",
							children: status
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex shrink-0 items-center gap-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center rounded-full border border-muted/25 bg-surface",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex size-11 items-center justify-center rounded-full text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40",
									"aria-label": "降低八度",
									disabled: params.octave <= 2,
									onClick: () => shiftOctave(-1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
										className: "size-5",
										"aria-hidden": "true"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-8 text-center font-mono text-sm leading-none tabular-nums sm:min-w-16",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "sm:hidden",
										children: midiToName(baseMidi(params.octave))
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden sm:inline",
										children: rangeLabel(params.octave)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "flex size-11 items-center justify-center rounded-full text-fg transition-transform duration-150 ease-out active:scale-[0.96] disabled:opacity-40",
									"aria-label": "升高八度",
									disabled: params.octave >= 6,
									onClick: () => shiftOctave(1),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
										className: "size-5",
										"aria-hidden": "true"
									})
								})
							]
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 min-h-0 flex-1 overflow-auto overscroll-contain pb-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 xl:h-full xl:grid-cols-[minmax(0,1.15fr)_minmax(18rem,0.85fr)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "order-2 rounded-3xl border border-muted/20 bg-surface p-3 sm:p-4 xl:order-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-sm font-medium",
										children: "振荡器"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs tracking-widest text-muted",
										children: "OSC"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 grid grid-cols-4 gap-2",
									role: "group",
									"aria-label": "波形",
									children: WAVEFORMS.map((wave) => {
										const active = params.waveform === wave;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											"aria-pressed": active,
											onClick: () => patchParams({ waveform: wave }),
											className: "flex h-12 flex-col items-center justify-center gap-0.5 rounded-xl border transition-colors duration-150 active:scale-[0.96] " + (active ? "border-accent bg-accent text-bg" : "border-muted/25 bg-bg text-fg"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WaveIcon, { type: wave }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs leading-none",
												children: WAVE_META[wave].name
											})]
										}, wave);
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-[auto_1fr_auto] xl:items-end",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-2 flex items-baseline justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-medium",
												children: "低通滤波"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs tracking-widest text-muted",
												children: "FILTER"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
												label: "截止",
												hint: "滤波器截止频率",
												value: params.cutoff,
												min: 80,
												max: 14e3,
												curve: "log",
												format: formatHz,
												defaultValue: DEFAULT_PARAMS.cutoff,
												onChange: (cutoff) => patchParams({ cutoff })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
												label: "谐振",
												hint: "滤波器谐振",
												value: params.resonance,
												min: .15,
												max: 18,
												format: formatQ,
												defaultValue: DEFAULT_PARAMS.resonance,
												onChange: (resonance) => patchParams({ resonance })
											})]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-2 flex items-baseline justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-medium",
												children: "包络"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs tracking-widest text-muted",
												children: "ADSR"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap gap-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
													label: "起音",
													hint: "起音时间",
													value: params.attack,
													min: .005,
													max: 2,
													curve: "log",
													format: formatTime,
													defaultValue: DEFAULT_PARAMS.attack,
													onChange: (attack) => patchParams({ attack })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
													label: "衰减",
													hint: "衰减时间",
													value: params.decay,
													min: .02,
													max: 2.5,
													curve: "log",
													format: formatTime,
													defaultValue: DEFAULT_PARAMS.decay,
													onChange: (decay) => patchParams({ decay })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
													label: "延音",
													hint: "延音电平",
													value: params.sustain,
													min: 0,
													max: 1,
													format: formatPct,
													defaultValue: DEFAULT_PARAMS.sustain,
													onChange: (sustain) => patchParams({ sustain })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
													label: "释音",
													hint: "释音时间",
													value: params.release,
													min: .02,
													max: 4,
													curve: "log",
													format: formatTime,
													defaultValue: DEFAULT_PARAMS.release,
													onChange: (release) => patchParams({ release })
												})
											]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mb-2 flex items-baseline justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-sm font-medium",
												children: "输出"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs tracking-widest text-muted",
												children: "LEVEL"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Knob, {
											label: "音量",
											hint: "主音量",
											value: params.volume,
											min: 0,
											max: 1,
											format: formatPct,
											defaultValue: DEFAULT_PARAMS.volume,
											onChange: (volume) => patchParams({ volume })
										})] })
									]
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "order-1 flex min-h-44 flex-col rounded-3xl border border-muted/20 bg-surface p-3 sm:p-4 xl:order-2 xl:h-full",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-baseline gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-sm font-medium",
												children: "示波器"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs tracking-widest text-muted",
												children: "SCOPE"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 truncate text-2xl leading-none font-semibold",
											children: notes.length > 0 ? notes.map(midiToName).join(" ") : "—"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "shrink-0 text-right font-mono text-xs leading-relaxed text-muted",
										children: [
											playing ? `${notes.length} 音` : "复音",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											lastMidi != null ? `${midiToName(lastMidi)} · ${formatHz(midiToFreq(lastMidi))}` : "—"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mt-3 min-h-32 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scope, { levelRef }), awake ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "pointer-events-none absolute inset-0 flex items-center justify-center font-mono text-xs text-muted",
										children: "等待信号"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-mono text-xs text-muted",
									children: [
										"电平 ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											ref: levelRef,
											children: "0"
										}),
										"%"
									]
								})
							]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "shrink-0 pt-2 pb-3",
					"aria-label": "键盘",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium",
								children: "键盘"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-mono text-xs text-muted",
								children: rangeLabel(params.octave)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, {
							octave: params.octave,
							notes
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs leading-relaxed text-muted",
							children: "低八度 Z S X D C V G B H N J M · 高八度 Q 2 W 3 E R 5 T 6 Y 7 U · 八度 [ ]"
						})
					]
				})
			]
		})]
	});
}
var SplitComponent = SynthApp;
//#endregion
export { SplitComponent as component };
